/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testeexuploadgit;

/**
 *
 * @author Admin
 */
public class Testeexuploadgit {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.print("Exemplo de upload no github");
    }
    
}
